plugins {
    id("com.android.application")
}

android {
    namespace = "ai.autoforge.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "ai.autoforge.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 5
        versionName = "0.4.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
