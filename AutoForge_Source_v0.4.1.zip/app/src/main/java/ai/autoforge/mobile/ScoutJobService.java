package ai.autoforge.mobile;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

/** Periodic background scout. Android may defer jobs to save battery. */
public class ScoutJobService extends JobService {
    private static final int JOB_ID = 43003;

    public static void configure(Context context, boolean enabled, int hours) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        scheduler.cancel(JOB_ID);
        SharedPreferences p = context.getSharedPreferences("autoforge", Context.MODE_PRIVATE);
        p.edit().putBoolean("scout_auto", enabled).putInt("scout_hours", hours).apply();
        if (!enabled) return;
        long interval = Math.max(60L * 60L * 1000L, hours * 60L * 60L * 1000L);
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(context, ScoutJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(interval)
                .build();
        scheduler.schedule(job);
    }

    public static void ensureDefault(Context context) {
        SharedPreferences p = context.getSharedPreferences("autoforge", Context.MODE_PRIVATE);
        boolean enabled = p.getBoolean("scout_auto", true);
        int hours = p.getInt("scout_hours", 24);
        if (enabled) configure(context, true, hours);
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try { ScoutScanner.scanAndStore(getApplicationContext()); }
            finally { jobFinished(params, false); }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
