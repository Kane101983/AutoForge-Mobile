package ai.autoforge.mobile;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1042;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                try {
                    android.content.Intent intent = fileChooserParams.createIntent();
                    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                    intent.putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "Dateiauswahl konnte nicht geöffnet werden", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this, webView), "AndroidBridge");
        ScoutJobService.ensureDefault(this);
        webView.loadUrl("file:///android_asset/index.html");
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || fileChooserCallback == null) return;
        Uri[] result = null;
        if (resultCode == Activity.RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                android.content.ClipData clip = data.getClipData();
                result = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(result);
        fileChooserCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private static class AndroidBridge {
        private final Context context;
        private final WebView webView;

        AndroidBridge(Context context, WebView webView) {
            this.context = context;
            this.webView = webView;
        }

        @JavascriptInterface
        public void download(String url, String token, String filename) {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                if (token != null && !token.isEmpty()) request.addRequestHeader("X-AutoForge-Token", token);
                request.setTitle(filename == null || filename.isEmpty() ? "AutoForge-Projekt" : filename);
                request.setDescription("AutoForge exportiert das Projekt als ZIP");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        filename == null || filename.isEmpty() ? "AutoForge_Project.zip" : filename);
                DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                dm.enqueue(request);
                toast("Download gestartet");
            } catch (Exception e) {
                toast("Download fehlgeschlagen: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void scanFreeAI(String callbackId) {
            new Thread(() -> callback(callbackId, ScoutScanner.scanAndStore(context))).start();
        }

        @JavascriptInterface
        public void getScoutCache(String callbackId) {
            callback(callbackId, ScoutScanner.cached(context));
        }

        @JavascriptInterface
        public void configureAutoScout(boolean enabled, int hours, String callbackId) {
            int safeHours = Math.max(1, Math.min(hours, 168));
            ScoutJobService.configure(context, enabled, safeHours);
            JSONObject result = new JSONObject();
            try {
                result.put("ok", true);
                result.put("enabled", enabled);
                result.put("hours", safeHours);
            } catch (Exception ignored) {}
            callback(callbackId, result.toString());
        }

        @JavascriptInterface
        public void openRouterChat(String apiKey, String model, String prompt, String system, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenRouter-Key fehlt");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("Kostenloses Modell fehlt");
                    JSONObject body = new JSONObject();
                    body.put("model", model.trim());
                    body.put("temperature", 0.2);
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) {
                        msgs.put(new JSONObject().put("role", "system").put("content", system));
                    }
                    msgs.put(new JSONObject().put("role", "user").put("content", prompt));
                    body.put("messages", msgs);
                    String raw = postJson("https://openrouter.ai/api/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Modellantwort");
                    String text = choices.getJSONObject(0).getJSONObject("message").optString("content", "");
                    result.put("ok", true);
                    result.put("text", text);
                    result.put("model", model.trim());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void openRouterChatWithAttachments(String apiKey, String model, String prompt, String system, String attachmentsJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenRouter-Key fehlt");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("Kostenloses Modell fehlt");
                    JSONArray content = new JSONArray();
                    content.put(new JSONObject().put("type", "text").put("text", prompt));
                    JSONArray atts = new JSONArray(attachmentsJson == null || attachmentsJson.isEmpty() ? "[]" : attachmentsJson);
                    StringBuilder textAppend = new StringBuilder();
                    for (int i = 0; i < atts.length(); i++) {
                        JSONObject a = atts.optJSONObject(i);
                        if (a == null) continue;
                        String mime = a.optString("mime", "");
                        String name = a.optString("name", "Anhang");
                        String dataUrl = a.optString("dataUrl", "");
                        String text = a.optString("text", "");
                        if (mime.startsWith("image/") && !dataUrl.isEmpty()) {
                            content.put(new JSONObject().put("type", "image_url")
                                    .put("image_url", new JSONObject().put("url", dataUrl)));
                        } else if (!text.isEmpty()) {
                            textAppend.append("\n\n--- Datei: ").append(name).append(" ---\n").append(text);
                        } else {
                            textAppend.append("\n\n[Anhang: ").append(name).append("; Typ: ").append(mime).append("]");
                        }
                    }
                    if (textAppend.length() > 0) {
                        content.put(new JSONObject().put("type", "text").put("text", textAppend.toString()));
                    }
                    JSONObject body = new JSONObject();
                    body.put("model", model.trim());
                    body.put("temperature", 0.2);
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) msgs.put(new JSONObject().put("role", "system").put("content", system));
                    msgs.put(new JSONObject().put("role", "user").put("content", content));
                    body.put("messages", msgs);
                    String raw = postJson("https://openrouter.ai/api/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Modellantwort");
                    Object contentOut = choices.getJSONObject(0).getJSONObject("message").opt("content");
                    String textOut = contentOut instanceof String ? (String) contentOut : String.valueOf(contentOut);
                    result.put("ok", true);
                    result.put("text", textOut);
                    result.put("model", model.trim());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void saveProject(String projectName, String projectJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.GERMANY).format(new Date());
                    String safe = safeName(projectName == null ? "Projekt" : projectName);
                    File rootBase = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    if (rootBase == null) rootBase = context.getFilesDir();
                    File root = new File(rootBase, "AutoForge/" + stamp + "_" + safe);
                    if (!root.mkdirs() && !root.isDirectory()) throw new IllegalStateException("Projektordner konnte nicht erstellt werden");
                    JSONObject project = parseProjectJson(projectJson);
                    JSONArray files = project.optJSONArray("files");
                    int written = 0;
                    if (files != null) {
                        String rootCanonical = root.getCanonicalPath() + File.separator;
                        for (int i = 0; i < files.length() && i < 80; i++) {
                            JSONObject f = files.optJSONObject(i);
                            if (f == null) continue;
                            String rel = f.optString("path", "").replace('\\', '/');
                            if (rel.isEmpty() || rel.startsWith("/") || rel.contains("../")) continue;
                            File out = new File(root, rel);
                            String outCanonical = out.getCanonicalPath();
                            if (!outCanonical.startsWith(rootCanonical)) continue;
                            File parent = out.getParentFile();
                            if (parent != null) parent.mkdirs();
                            try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8))) {
                                bw.write(f.optString("content", ""));
                            }
                            written++;
                        }
                    }
                    if (written == 0) {
                        File fallback = new File(root, "AUTOFORGE_RESPONSE.txt");
                        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fallback), StandardCharsets.UTF_8))) {
                            bw.write(projectJson);
                        }
                        written = 1;
                    }
                    File zip = new File(root.getParentFile(), root.getName() + ".zip");
                    zipFolder(root, zip, root);
                    result.put("ok", true);
                    result.put("files", written);
                    result.put("folder", root.getAbsolutePath());
                    result.put("zip", zip.getAbsolutePath());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void toast(String message) {
            ((Activity) context).runOnUiThread(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
        }

        private void callback(String callbackId, String json) {
            ((Activity) context).runOnUiThread(() -> {
                String js = "window.AFBridgeResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(json) + ")";
                webView.evaluateJavascript(js, null);
            });
        }

        private static double number(Object v) {
            try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0d; }
        }

        private static String classify(String text) {
            String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
            if (t.contains("coder") || t.contains("coding") || t.contains("code")) return "coding";
            if (t.contains("image") || t.contains("diffusion") || t.contains("flux")) return "image";
            if (t.contains("video")) return "video";
            if (t.contains("audio") || t.contains("speech") || t.contains("music")) return "audio";
            if (t.contains("3d") || t.contains("mesh")) return "3d";
            if (t.contains("agent")) return "agents";
            if (t.contains("vision") || t.contains("multimodal")) return "vision";
            return "general";
        }

        private static String get(String url, String token) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000); c.setReadTimeout(25000); c.setRequestMethod("GET");
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.4");
            if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            return readResponse(c);
        }

        private static String postJson(String url, String body, String token) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(120000); c.setRequestMethod("POST");
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.4");
            if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
            return readResponse(c);
        }

        private static String readResponse(HttpURLConnection c) throws Exception {
            int code = c.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (is == null) throw new IllegalStateException("HTTP " + code);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + sb.toString().trim());
            return sb.toString();
        }

        private static JSONObject parseProjectJson(String text) throws Exception {
            String s = text == null ? "" : text.trim();
            if (s.startsWith("```")) {
                s = s.replaceFirst("^```(?:json)?\\s*", "");
                s = s.replaceFirst("\\s*```$", "");
            }
            int a = s.indexOf('{'); int b = s.lastIndexOf('}');
            if (a >= 0 && b > a) s = s.substring(a, b + 1);
            return new JSONObject(s);
        }

        private static String safeName(String s) {
            String x = s.replaceAll("[^a-zA-Z0-9äöüÄÖÜß_-]+", "_").replaceAll("^_+|_+$", "");
            if (x.isEmpty()) x = "Projekt";
            return x.length() > 45 ? x.substring(0, 45) : x;
        }

        private static void zipFolder(File current, File zipFile, File root) throws Exception {
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
                addZip(current, root, zos);
            }
        }

        private static void addZip(File file, File root, ZipOutputStream zos) throws Exception {
            if (file.isDirectory()) {
                File[] children = file.listFiles();
                if (children != null) for (File child : children) addZip(child, root, zos);
                return;
            }
            String name = root.toURI().relativize(file.toURI()).getPath();
            zos.putNextEntry(new ZipEntry(name));
            try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
            }
            zos.closeEntry();
        }
    }
}
