# AutoForge Mobile MVP: no custom shrinker rules required.
